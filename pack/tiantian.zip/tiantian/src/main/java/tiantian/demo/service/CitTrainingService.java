package tiantian.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import tiantian.demo.reppository.model.CitTrainingModel;

/**
 * @author davine
 * @date 2022/7/23
 */
public interface CitTrainingService extends IService<CitTrainingModel> {
}
